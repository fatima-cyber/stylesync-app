import { PrismaClient } from "@/app/generated/prisma";

// Prevent multiple instances in development
const globalForPrisma = global as unknown as { prisma?: PrismaClient };

export const prismaClient: PrismaClient =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ["error", "warn"],
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prismaClient;
}

export default prismaClient;


