import { NextResponse } from "next/server";
import prismaClient from "@/app/lib/prisma";

export const runtime = "nodejs";

export async function GET() {
  try {
    // Simple DB roundtrip to validate connectivity
    await prismaClient.$queryRaw`SELECT 1`;
    return NextResponse.json({ status: "ok" }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ status: "db_error" }, { status: 500 });
  }
}


